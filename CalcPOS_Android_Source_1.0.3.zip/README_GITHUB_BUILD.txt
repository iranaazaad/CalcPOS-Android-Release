CalcPOS License Manager Android - GitHub Build Package

Upload the CONTENTS of this folder to the root of a private GitHub repository.
Then open Actions > Build Android APK > Run workflow.
The generated APK will be available as the artifact named CalcPOS-License-Manager-debug.
