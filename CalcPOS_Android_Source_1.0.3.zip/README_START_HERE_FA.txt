CalcPOS License Manager Android - GitHub Build (Simple)

1) Create a new PRIVATE GitHub repository.
2) Upload the CONTENTS of this extracted folder, not the ZIP itself.
3) Commit the files.
4) Open Actions > Build Android APK > Run workflow.
5) After the run becomes green, download the artifact named CalcPOS-License-Manager-debug.

This package intentionally contains only the Android client. It contains no RSA private key.
