CalcPOS License Manager Android 1.0.2 - GitHub Build Fixed

اصلاحات:
1) رفع تداخل usesCleartextTraffic در Manifest نسخه Debug
2) حذف import اشتباه weight که باعث خطای Kotlin می‌شد
3) compileSdk/targetSdk روی API 35
4) Workflow آماده GitHub Actions

ساخت APK:
فایل‌ها را در ریشه یک Repository آپلود کنید.
GitHub Actions به صورت خودکار APK Debug را می‌سازد.
