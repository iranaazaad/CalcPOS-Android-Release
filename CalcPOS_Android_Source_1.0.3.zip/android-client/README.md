# CalcPOS License Manager Android

پروژه Native Android با Kotlin و Jetpack Compose.

## Build Debug

```bat
gradlew.bat :app:assembleDebug
```

## آدرس سرور در Emulator

```text
http://10.0.2.2:8765
```

## آدرس سرور روی گوشی واقعی

```text
http://IP-PC:8765
```

این آدرس فقط در Debug پذیرفته می‌شود. Release به HTTPS نیاز دارد.
