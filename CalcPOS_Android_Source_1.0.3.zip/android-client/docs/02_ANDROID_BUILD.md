# ساخت برنامه Android

## نسخه‌های پروژه

- Android Gradle Plugin: 9.3.0
- Gradle: 9.5.0
- Kotlin / Compose Compiler: 2.4.10
- Compose BOM: 2026.06.00
- compileSdk / targetSdk: 37
- minSdk: 26
- JDK: 17

## ساخت با Android Studio

1. Android Studio را باز کنید.
2. گزینه Open را بزنید و پوشه `android-client` را انتخاب کنید.
3. در SDK Manager، Android API 37 و Build Tools 36.0.0 را نصب کنید.
4. Gradle JDK را روی JDK 17 قرار دهید.
5. بعد از Sync، از منوی Build گزینه Build APK(s) را بزنید.

خروجی Debug:

```text
android-client/app/build/outputs/apk/debug/app-debug.apk
```

## ساخت خط فرمان

```bat
cd android-client
gradlew.bat :app:assembleDebug
```

اسکریپت `gradlew.bat` در اولین اجرا Gradle 9.5.0 را دانلود می‌کند.

## ساخت Release امضاشده

ابتدا keystore خصوصی بسازید:

```bat
keytool -genkeypair -v -keystore calcpos-android-release.jks -alias calcpos -keyalg RSA -keysize 3072 -validity 10000
```

سپس در Android Studio از Build > Generate Signed App Bundle or APK استفاده کنید. فایل keystore و رمز آن را داخل پروژه یا ZIP نگه ندارید.
