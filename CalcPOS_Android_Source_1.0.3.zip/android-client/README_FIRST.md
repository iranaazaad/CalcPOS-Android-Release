# CalcPOS License Manager Android Client 1.0

این بسته فقط سورس کلاینت اندروید است و هیچ کلید خصوصی RSA در آن وجود ندارد.
برای کارکرد برنامه باید Signing Server خصوصی جداگانه راه‌اندازی شود.
برای ساخت Debug، `gradlew.bat :app:assembleDebug` را اجرا کنید.
