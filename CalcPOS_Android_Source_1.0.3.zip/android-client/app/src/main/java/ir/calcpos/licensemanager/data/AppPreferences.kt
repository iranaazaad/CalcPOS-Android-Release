package ir.calcpos.licensemanager.data

import android.content.Context

class AppPreferences(context: Context) {
    private val preferences = context.getSharedPreferences("calcpos_android_preferences", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = preferences.getString(KEY_SERVER_URL, "http://10.0.2.2:8765") ?: "http://10.0.2.2:8765"
        set(value) = preferences.edit().putString(KEY_SERVER_URL, value.trim()).apply()

    var username: String
        get() = preferences.getString(KEY_USERNAME, "admin") ?: "admin"
        set(value) = preferences.edit().putString(KEY_USERNAME, value.trim()).apply()

    var darkTheme: Boolean
        get() = preferences.getBoolean(KEY_DARK_THEME, false)
        set(value) = preferences.edit().putBoolean(KEY_DARK_THEME, value).apply()

    companion object {
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_USERNAME = "username"
        private const val KEY_DARK_THEME = "dark_theme"
    }
}
