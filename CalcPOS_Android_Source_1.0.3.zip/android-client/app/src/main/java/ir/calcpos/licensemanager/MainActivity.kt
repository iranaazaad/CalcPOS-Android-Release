package ir.calcpos.licensemanager

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.calcpos.licensemanager.ui.AppViewModel
import ir.calcpos.licensemanager.ui.CalcPOSLicenseApp
import ir.calcpos.licensemanager.ui.theme.CalcPOSTheme
import java.io.File

class MainActivity : ComponentActivity() {
    private val viewModel: AppViewModel by viewModels()
    private var pendingLicenseContent: String? = null

    private val saveDocument = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val content = pendingLicenseContent
        pendingLicenseContent = null
        if (uri != null && content != null) {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(content.trim())
                it.newLine()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            CalcPOSTheme(darkTheme = state.darkTheme) {
                CalcPOSLicenseApp(
                    state = state,
                    viewModel = viewModel,
                    onShareLicense = ::shareLicense,
                    onSaveLicense = ::saveLicense
                )
            }
        }
    }

    private fun saveLicense(token: String, customer: String) {
        pendingLicenseContent = token
        saveDocument.launch("${safeFileName(customer)}.lic")
    }

    private fun shareLicense(token: String, customer: String) {
        val directory = File(cacheDir, "shared_licenses").apply { mkdirs() }
        val file = File(directory, "${safeFileName(customer)}.lic")
        file.writeText(token.trim() + "\n", Charsets.UTF_8)
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_SUBJECT, "لایسنس CalcPOS - $customer")
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "فایل لایسنس CalcPOS برای $customer")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری فایل لایسنس"))
    }

    private fun safeFileName(value: String): String {
        val cleaned = value.trim().map { character ->
            if (character.isLetterOrDigit() || character in "-_ ") character else '_'
        }.joinToString("").replace(' ', '_').take(60)
        return cleaned.ifBlank { "CalcPOS_License" }
    }
}
