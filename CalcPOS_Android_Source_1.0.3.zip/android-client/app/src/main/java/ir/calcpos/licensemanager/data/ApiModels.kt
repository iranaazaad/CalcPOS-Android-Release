package ir.calcpos.licensemanager.data

import org.json.JSONArray
import org.json.JSONObject

enum class LicenseType(val apiValue: String, val title: String) {
    Subscription("subscription", "مدت‌دار"),
    Perpetual("perpetual", "دائمی")
}

enum class LicenseStatusFilter(val apiValue: String, val title: String) {
    All("all", "همه"),
    Active("active", "فعال"),
    Perpetual("perpetual", "دائمی"),
    Expired("expired", "منقضی"),
    Revoked("revoked", "باطل")
}

data class LoginSession(
    val accessToken: String,
    val expiresAt: Long,
    val username: String
)

data class LicenseStats(
    val total: Int = 0,
    val active: Int = 0,
    val perpetual: Int = 0,
    val expiredOrRevoked: Int = 0
)

data class LicenseRecord(
    val id: Int,
    val licenseId: String,
    val customer: String,
    val hwid: String,
    val type: String,
    val durationDays: Int?,
    val issuedAt: String,
    val expiresAt: String?,
    val versionPrefix: String,
    val token: String,
    val status: String,
    val notes: String,
    val createdBy: String,
    val revokedAt: String?,
    val isExpired: Boolean
) {
    val isPerpetual: Boolean get() = type == "perpetual"
    val isRevoked: Boolean get() = status == "revoked"

    val statusTitle: String
        get() = when {
            isRevoked -> "باطل‌شده"
            isExpired -> "منقضی"
            isPerpetual -> "دائمی"
            else -> "فعال"
        }
}

data class IssuedLicense(
    val record: LicenseRecord,
    val token: String
)

data class IssueLicenseRequest(
    val customer: String,
    val hwid: String,
    val type: LicenseType,
    val days: Int?,
    val versionPrefix: String,
    val notes: String
)

internal fun JSONObject.nullableString(name: String): String? {
    if (!has(name) || isNull(name)) return null
    return optString(name).takeIf { it.isNotBlank() }
}

internal fun JSONObject.toLicenseRecord(): LicenseRecord = LicenseRecord(
    id = getInt("id"),
    licenseId = getString("license_id"),
    customer = getString("customer"),
    hwid = getString("hwid"),
    type = getString("type"),
    durationDays = if (isNull("duration_days")) null else optInt("duration_days"),
    issuedAt = getString("issued_at"),
    expiresAt = nullableString("expires_at"),
    versionPrefix = getString("version_prefix"),
    token = getString("token"),
    status = getString("status"),
    notes = optString("notes"),
    createdBy = optString("created_by", "admin"),
    revokedAt = nullableString("revoked_at"),
    isExpired = optBoolean("is_expired", false)
)

internal fun JSONArray.toLicenseRecords(): List<LicenseRecord> = buildList {
    for (index in 0 until length()) {
        add(getJSONObject(index).toLicenseRecord())
    }
}
