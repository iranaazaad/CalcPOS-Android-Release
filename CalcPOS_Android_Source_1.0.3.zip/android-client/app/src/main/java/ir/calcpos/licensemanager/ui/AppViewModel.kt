package ir.calcpos.licensemanager.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.calcpos.licensemanager.data.ApiClient
import ir.calcpos.licensemanager.data.ApiException
import ir.calcpos.licensemanager.data.AppPreferences
import ir.calcpos.licensemanager.data.IssueLicenseRequest
import ir.calcpos.licensemanager.data.IssuedLicense
import ir.calcpos.licensemanager.data.LicenseRecord
import ir.calcpos.licensemanager.data.LicenseStats
import ir.calcpos.licensemanager.data.LicenseStatusFilter
import ir.calcpos.licensemanager.data.LicenseType
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppScreen { Dashboard, Issue, History, Settings }

data class LicenseUiState(
    val loggedIn: Boolean = false,
    val username: String = "admin",
    val password: String = "",
    val serverUrl: String = "http://10.0.2.2:8765",
    val screen: AppScreen = AppScreen.Dashboard,
    val loading: Boolean = false,
    val refreshing: Boolean = false,
    val error: String? = null,
    val message: String? = null,
    val darkTheme: Boolean = false,
    val stats: LicenseStats = LicenseStats(),
    val records: List<LicenseRecord> = emptyList(),
    val search: String = "",
    val filter: LicenseStatusFilter = LicenseStatusFilter.All,
    val selectedRecord: LicenseRecord? = null,
    val customer: String = "",
    val hwid: String = "",
    val licenseType: LicenseType = LicenseType.Subscription,
    val days: String = "30",
    val versionPrefix: String = "1.6",
    val notes: String = "",
    val lastIssued: IssuedLicense? = null
)

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = AppPreferences(application)
    private val _uiState = MutableStateFlow(
        LicenseUiState(
            username = preferences.username,
            serverUrl = preferences.serverUrl,
            darkTheme = preferences.darkTheme
        )
    )
    val uiState: StateFlow<LicenseUiState> = _uiState.asStateFlow()

    private var sessionToken: String? = null

    fun updateUsername(value: String) = _uiState.update { it.copy(username = value) }
    fun updatePassword(value: String) = _uiState.update { it.copy(password = value) }
    fun updateServerUrl(value: String) = _uiState.update { it.copy(serverUrl = value) }
    fun updateCustomer(value: String) = _uiState.update { it.copy(customer = value) }
    fun updateHwid(value: String) = _uiState.update { it.copy(hwid = value) }
    fun updateDays(value: String) = _uiState.update { it.copy(days = value.filter(Char::isDigit).take(5)) }
    fun updateVersionPrefix(value: String) = _uiState.update { it.copy(versionPrefix = value.take(12)) }
    fun updateNotes(value: String) = _uiState.update { it.copy(notes = value.take(1000)) }
    fun updateSearch(value: String) = _uiState.update { it.copy(search = value.take(200)) }

    fun selectLicenseType(value: LicenseType) {
        _uiState.update {
            it.copy(
                licenseType = value,
                days = if (value == LicenseType.Perpetual) "" else it.days.ifBlank { "30" }
            )
        }
    }

    fun setQuickDays(days: Int) = _uiState.update {
        it.copy(licenseType = LicenseType.Subscription, days = days.toString())
    }

    fun selectScreen(screen: AppScreen) = _uiState.update { it.copy(screen = screen) }

    fun selectFilter(filter: LicenseStatusFilter) {
        _uiState.update { it.copy(filter = filter) }
        refresh()
    }

    fun setDarkTheme(enabled: Boolean) {
        preferences.darkTheme = enabled
        _uiState.update { it.copy(darkTheme = enabled) }
    }

    fun saveServerSettings() {
        val state = _uiState.value
        runCatching { ApiClient.normalizeBaseUrl(state.serverUrl) }
            .onSuccess {
                preferences.serverUrl = state.serverUrl
                preferences.username = state.username
                _uiState.update { current -> current.copy(message = "تنظیمات اتصال ذخیره شد.") }
            }
            .onFailure { showError(it.message ?: "آدرس سرور معتبر نیست.") }
    }

    fun login() {
        val state = _uiState.value
        if (state.username.isBlank() || state.password.isBlank()) {
            showError("نام کاربری و رمز ورود را وارد کنید.")
            return
        }
        _uiState.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                val client = ApiClient(state.serverUrl)
                val session = client.login(state.username.trim(), state.password)
                sessionToken = session.accessToken
                preferences.serverUrl = state.serverUrl
                preferences.username = session.username
                _uiState.update {
                    it.copy(
                        loggedIn = true,
                        username = session.username,
                        password = "",
                        loading = false,
                        screen = AppScreen.Dashboard,
                        message = "ورود با موفقیت انجام شد."
                    )
                }
                loadDashboardData()
            } catch (exception: Exception) {
                _uiState.update { it.copy(loading = false) }
                handleException(exception)
            }
        }
    }

    fun logout(message: String? = null) {
        sessionToken = null
        _uiState.update {
            it.copy(
                loggedIn = false,
                password = "",
                records = emptyList(),
                stats = LicenseStats(),
                selectedRecord = null,
                lastIssued = null,
                message = message
            )
        }
    }

    fun refresh() {
        if (!_uiState.value.loggedIn || sessionToken == null) return
        viewModelScope.launch { loadDashboardData() }
    }

    fun issueLicense() {
        val state = _uiState.value
        val normalizedHwid = state.hwid.lowercase().replace("-", "").replace(" ", "")
        if (state.customer.trim().isBlank()) {
            showError("نام مشتری وارد نشده است.")
            return
        }
        if (!normalizedHwid.matches(Regex("^[0-9a-f]{64}$"))) {
            showError("HWID باید دقیقاً ۶۴ کاراکتر هگزادسیمال باشد.")
            return
        }
        val duration = if (state.licenseType == LicenseType.Subscription) state.days.toIntOrNull() else null
        if (state.licenseType == LicenseType.Subscription && (duration == null || duration !in 1..36500)) {
            showError("مدت لایسنس باید بین ۱ تا ۳۶۵۰۰ روز باشد.")
            return
        }
        if (!state.versionPrefix.matches(Regex("^\\d+\\.\\d+$"))) {
            showError("نسخه سازگار باید مانند 1.6 باشد.")
            return
        }
        val token = sessionToken ?: return logout("نشست شما پایان یافته است.")
        _uiState.update { it.copy(loading = true, error = null, lastIssued = null) }
        viewModelScope.launch {
            try {
                val issued = ApiClient(state.serverUrl).issue(
                    token,
                    IssueLicenseRequest(
                        customer = state.customer.trim(),
                        hwid = normalizedHwid,
                        type = state.licenseType,
                        days = duration,
                        versionPrefix = state.versionPrefix.trim(),
                        notes = state.notes.trim()
                    )
                )
                _uiState.update {
                    it.copy(
                        loading = false,
                        lastIssued = issued,
                        customer = "",
                        hwid = "",
                        notes = "",
                        message = "لایسنس با موفقیت صادر و ثبت شد."
                    )
                }
                loadDashboardData(showRefresh = false)
            } catch (exception: Exception) {
                _uiState.update { it.copy(loading = false) }
                handleException(exception)
            }
        }
    }

    fun revoke(record: LicenseRecord) {
        val token = sessionToken ?: return logout("نشست شما پایان یافته است.")
        _uiState.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            try {
                ApiClient(_uiState.value.serverUrl).revoke(token, record.id)
                _uiState.update {
                    it.copy(
                        loading = false,
                        selectedRecord = null,
                        message = "رکورد لایسنس باطل شد. ابطال برای CalcPOS آفلاین فوری نیست."
                    )
                }
                loadDashboardData(showRefresh = false)
            } catch (exception: Exception) {
                _uiState.update { it.copy(loading = false) }
                handleException(exception)
            }
        }
    }

    fun selectRecord(record: LicenseRecord?) = _uiState.update { it.copy(selectedRecord = record) }
    fun clearNotice() = _uiState.update { it.copy(error = null, message = null) }
    fun clearLastIssued() = _uiState.update { it.copy(lastIssued = null) }

    private suspend fun loadDashboardData(showRefresh: Boolean = true) {
        val token = sessionToken ?: return
        val state = _uiState.value
        if (showRefresh) _uiState.update { it.copy(refreshing = true, error = null) }
        try {
            val client = ApiClient(state.serverUrl)
            val statsRequest = viewModelScope.async { client.stats(token) }
            val recordsRequest = viewModelScope.async { client.licenses(token, state.search, state.filter) }
            val stats = statsRequest.await()
            val records = recordsRequest.await()
            _uiState.update { it.copy(stats = stats, records = records, refreshing = false) }
        } catch (exception: Exception) {
            _uiState.update { it.copy(refreshing = false) }
            handleException(exception)
        }
    }

    private fun handleException(exception: Exception) {
        if (exception is ApiException && exception.statusCode == 401 && _uiState.value.loggedIn) {
            logout("نشست منقضی شد؛ دوباره وارد شوید.")
            return
        }
        showError(exception.message ?: "خطای پیش‌بینی‌نشده رخ داد.")
    }

    private fun showError(message: String) = _uiState.update { it.copy(error = message) }
}
