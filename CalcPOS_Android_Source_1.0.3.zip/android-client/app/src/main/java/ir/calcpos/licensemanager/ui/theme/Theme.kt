package ir.calcpos.licensemanager.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF155EEF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE7FF),
    onPrimaryContainer = Color(0xFF002A78),
    secondary = Color(0xFF087E8B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1F6FA),
    onSecondaryContainer = Color(0xFF00363C),
    tertiary = Color(0xFFC66A00),
    tertiaryContainer = Color(0xFFFFDDB8),
    background = Color(0xFFF7F9FC),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE9EDF5),
    outline = Color(0xFF727987),
    error = Color(0xFFBA1A1A)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFADC6FF),
    onPrimary = Color(0xFF002E69),
    primaryContainer = Color(0xFF06459F),
    onPrimaryContainer = Color(0xFFD9E4FF),
    secondary = Color(0xFF84D3DD),
    onSecondary = Color(0xFF00363C),
    secondaryContainer = Color(0xFF00505A),
    onSecondaryContainer = Color(0xFFA0F0FA),
    tertiary = Color(0xFFFFB870),
    tertiaryContainer = Color(0xFF6D3900),
    background = Color(0xFF0C111B),
    surface = Color(0xFF121925),
    surfaceVariant = Color(0xFF252E3D),
    outline = Color(0xFF8D95A5),
    error = Color(0xFFFFB4AB)
)

private val CalcPosTypography = Typography(
    displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 32.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 25.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 14.sp)
)

@Composable
fun CalcPOSTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = CalcPosTypography,
        content = content
    )
}
