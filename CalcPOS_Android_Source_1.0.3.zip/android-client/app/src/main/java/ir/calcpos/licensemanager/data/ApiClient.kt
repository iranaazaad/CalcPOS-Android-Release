package ir.calcpos.licensemanager.data

import ir.calcpos.licensemanager.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class ApiException(val statusCode: Int, override val message: String) : Exception(message)

class ApiClient(serverUrl: String) {
    private val baseUrl = normalizeBaseUrl(serverUrl)

    suspend fun health(): String = withContext(Dispatchers.IO) {
        request("GET", "/health").optString("status", "unknown")
    }

    suspend fun login(username: String, password: String): LoginSession = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("username", username)
            .put("password", password)
        val response = request("POST", "/api/v1/auth/login", body = body)
        LoginSession(
            accessToken = response.getString("access_token"),
            expiresAt = response.getLong("expires_at"),
            username = response.getString("username")
        )
    }

    suspend fun stats(token: String): LicenseStats = withContext(Dispatchers.IO) {
        val response = request("GET", "/api/v1/stats", token)
        LicenseStats(
            total = response.optInt("total"),
            active = response.optInt("active"),
            perpetual = response.optInt("perpetual"),
            expiredOrRevoked = response.optInt("expired_or_revoked")
        )
    }

    suspend fun licenses(
        token: String,
        query: String,
        filter: LicenseStatusFilter
    ): List<LicenseRecord> = withContext(Dispatchers.IO) {
        val encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
        val encodedStatus = URLEncoder.encode(filter.apiValue, StandardCharsets.UTF_8.name())
        request("GET", "/api/v1/licenses?query=$encodedQuery&status=$encodedStatus", token)
            .getJSONArray("items")
            .toLicenseRecords()
    }

    suspend fun issue(token: String, input: IssueLicenseRequest): IssuedLicense = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("customer", input.customer)
            .put("hwid", input.hwid)
            .put("type", input.type.apiValue)
            .put("version_prefix", input.versionPrefix)
            .put("notes", input.notes)
        if (input.days == null) body.put("days", JSONObject.NULL) else body.put("days", input.days)
        val response = request("POST", "/api/v1/licenses/issue", token, body)
        IssuedLicense(
            record = response.getJSONObject("record").toLicenseRecord(),
            token = response.getString("token")
        )
    }

    suspend fun revoke(token: String, recordId: Int): LicenseRecord = withContext(Dispatchers.IO) {
        request("POST", "/api/v1/licenses/$recordId/revoke", token).toLicenseRecord()
    }

    private fun request(
        method: String,
        path: String,
        token: String? = null,
        body: JSONObject? = null
    ): JSONObject {
        val connection = URI(baseUrl + path).toURL().openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 15_000
            connection.readTimeout = 30_000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", "CalcPOS-License-Manager-Android/${BuildConfig.VERSION_NAME}")
            if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.bufferedWriter(StandardCharsets.UTF_8).use { it.write(body.toString()) }
            }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = runCatching { JSONObject(text).optString("detail") }.getOrNull()
                    ?.takeIf { it.isNotBlank() }
                    ?: "خطای ارتباط با سرور ($code)"
                throw ApiException(code, detail)
            }
            return if (text.isBlank()) JSONObject() else JSONObject(text)
        } catch (exception: ApiException) {
            throw exception
        } catch (exception: Exception) {
            throw ApiException(0, exception.message ?: "ارتباط با سرور برقرار نشد.")
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        fun normalizeBaseUrl(value: String): String {
            val normalized = value.trim().trimEnd('/')
            require(normalized.startsWith("https://") || normalized.startsWith("http://")) {
                "آدرس سرور باید با https:// یا http:// شروع شود."
            }
            if (!BuildConfig.DEBUG && normalized.startsWith("http://")) {
                throw IllegalArgumentException("نسخه نهایی فقط اتصال HTTPS را قبول می‌کند.")
            }
            return normalized
        }
    }
}
