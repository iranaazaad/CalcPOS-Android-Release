package ir.calcpos.licensemanager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import ir.calcpos.licensemanager.BuildConfig
import ir.calcpos.licensemanager.data.LicenseRecord
import ir.calcpos.licensemanager.data.LicenseStatusFilter
import ir.calcpos.licensemanager.data.LicenseType
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

@Composable
fun CalcPOSLicenseApp(
    state: LicenseUiState,
    viewModel: AppViewModel,
    onShareLicense: (String, String) -> Unit,
    onSaveLicense: (String, String) -> Unit
) {
    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (!state.loggedIn) {
            LoginScreen(state, viewModel)
        } else {
            MainDashboard(state, viewModel, onShareLicense, onSaveLicense)
        }
    }
}

@Composable
private fun LoginScreen(state: LicenseUiState, viewModel: AppViewModel) {
    var showPassword by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(state.error, state.message) {
        state.error?.let { snackbar.showSnackbar(it) }
        state.message?.let { snackbar.showSnackbar(it) }
        if (state.error != null || state.message != null) viewModel.clearNotice()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding(),
            contentAlignment = Alignment.Center
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Surface(
                        modifier = Modifier.size(86.dp),
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.AdminPanelSettings,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("CalcPOS", style = MaterialTheme.typography.displaySmall)
                    Text(
                        "مدیریت امن لایسنس",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(26.dp))
                }
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(28.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(22.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text("ورود مدیر", style = MaterialTheme.typography.titleLarge)
                            Text(
                                "کلید خصوصی روی Signing Server باقی می‌ماند و وارد گوشی نمی‌شود.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = state.serverUrl,
                                onValueChange = viewModel::updateServerUrl,
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("آدرس Signing Server") },
                                placeholder = { Text("https://license.example.com") },
                                singleLine = true,
                                leadingIcon = { Icon(Icons.Rounded.Security, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
                                supportingText = {
                                    if (BuildConfig.DEBUG) {
                                        Text("برای تست شبکه داخلی، نسخه Debug اتصال HTTP را نیز قبول می‌کند.")
                                    } else {
                                        Text("نسخه Release فقط HTTPS را قبول می‌کند.")
                                    }
                                }
                            )
                            OutlinedTextField(
                                value = state.username,
                                onValueChange = viewModel::updateUsername,
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("نام کاربری") },
                                singleLine = true,
                                leadingIcon = { Icon(Icons.Rounded.Person, null) },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                            )
                            OutlinedTextField(
                                value = state.password,
                                onValueChange = viewModel::updatePassword,
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("رمز ورود") },
                                singleLine = true,
                                leadingIcon = { Icon(Icons.Rounded.Key, null) },
                                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    TextButton(onClick = { showPassword = !showPassword }) {
                                        Text(if (showPassword) "پنهان" else "نمایش")
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { viewModel.login() })
                            )
                            Button(
                                onClick = viewModel::login,
                                modifier = Modifier.fillMaxWidth().height(54.dp),
                                enabled = !state.loading,
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                if (state.loading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(22.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                } else {
                                    Icon(Icons.Rounded.VpnKey, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("ورود امن")
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "نسخه ${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainDashboard(
    state: LicenseUiState,
    viewModel: AppViewModel,
    onShareLicense: (String, String) -> Unit,
    onSaveLicense: (String, String) -> Unit
) {
    val snackbar = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current
    var revokeTarget by remember { mutableStateOf<LicenseRecord?>(null) }

    LaunchedEffect(state.error, state.message) {
        state.error?.let { snackbar.showSnackbar(it) }
        state.message?.let { snackbar.showSnackbar(it) }
        if (state.error != null || state.message != null) viewModel.clearNotice()
    }

    Scaffold(
        modifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing),
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(screenTitle(state.screen), style = MaterialTheme.typography.titleLarge)
                        Text(
                            "مدیر: ${state.username}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::refresh, enabled = !state.refreshing) {
                        if (state.refreshing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Rounded.Refresh, "به‌روزرسانی")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = state.screen == AppScreen.Dashboard,
                    onClick = { viewModel.selectScreen(AppScreen.Dashboard) },
                    icon = { Icon(Icons.Rounded.Dashboard, null) },
                    label = { Text("داشبورد") }
                )
                NavigationBarItem(
                    selected = state.screen == AppScreen.Issue,
                    onClick = { viewModel.selectScreen(AppScreen.Issue) },
                    icon = { Icon(Icons.Rounded.VpnKey, null) },
                    label = { Text("صدور") }
                )
                NavigationBarItem(
                    selected = state.screen == AppScreen.History,
                    onClick = { viewModel.selectScreen(AppScreen.History) },
                    icon = { Icon(Icons.Rounded.History, null) },
                    label = { Text("سوابق") }
                )
                NavigationBarItem(
                    selected = state.screen == AppScreen.Settings,
                    onClick = { viewModel.selectScreen(AppScreen.Settings) },
                    icon = { Icon(Icons.Rounded.Settings, null) },
                    label = { Text("تنظیمات") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (state.screen) {
                AppScreen.Dashboard -> DashboardScreen(state, viewModel::selectRecord)
                AppScreen.Issue -> IssueScreen(
                    state = state,
                    viewModel = viewModel,
                    onCopy = { clipboard.setText(AnnotatedString(it)) },
                    onShare = onShareLicense,
                    onSave = onSaveLicense
                )
                AppScreen.History -> HistoryScreen(state, viewModel)
                AppScreen.Settings -> SettingsScreen(state, viewModel)
            }

            if (state.loading) {
                Box(
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Card(shape = RoundedCornerShape(20.dp)) {
                        Row(
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                            Spacer(Modifier.width(12.dp))
                            Text("در حال انجام عملیات…")
                        }
                    }
                }
            }
        }
    }

    state.selectedRecord?.let { record ->
        LicenseDetailsDialog(
            record = record,
            onDismiss = { viewModel.selectRecord(null) },
            onCopyToken = { clipboard.setText(AnnotatedString(record.token)) },
            onCopyHwid = { clipboard.setText(AnnotatedString(record.hwid)) },
            onShare = { onShareLicense(record.token, record.customer) },
            onSave = { onSaveLicense(record.token, record.customer) },
            onRevoke = { revokeTarget = record }
        )
    }

    revokeTarget?.let { record ->
        AlertDialog(
            onDismissRequest = { revokeTarget = null },
            icon = { Icon(Icons.Rounded.DeleteForever, null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("ابطال رکورد لایسنس") },
            text = {
                Text("رکورد «${record.customer}» باطل شود؟ این کار کد آفلاین صادرشده را روی دستگاه مشتری فوراً غیرفعال نمی‌کند.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        revokeTarget = null
                        viewModel.revoke(record)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("ابطال رکورد") }
            },
            dismissButton = { TextButton(onClick = { revokeTarget = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun DashboardScreen(state: LicenseUiState, onRecordClick: (LicenseRecord) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                            Icon(
                                Icons.Rounded.Security,
                                null,
                                modifier = Modifier.padding(10.dp).size(28.dp),
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("مرکز صدور لایسنس", style = MaterialTheme.typography.titleLarge)
                            Text(
                                "اتصال امن به Signing Server برقرار است",
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("کل لایسنس‌ها", state.stats.total, Icons.Rounded.Dashboard, Modifier.weight(1f))
                StatCard("فعال", state.stats.active, Icons.Rounded.CheckCircle, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("دائمی", state.stats.perpetual, Icons.Rounded.AllInclusive, Modifier.weight(1f))
                StatCard("منقضی / باطل", state.stats.expiredOrRevoked, Icons.Rounded.ErrorOutline, Modifier.weight(1f))
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("آخرین لایسنس‌ها", style = MaterialTheme.typography.titleLarge)
                Text("${toPersianDigits(state.records.size)} رکورد", color = MaterialTheme.colorScheme.outline)
            }
        }
        if (state.records.isEmpty()) {
            item { EmptyState("هنوز لایسنسی ثبت نشده است.") }
        } else {
            items(state.records.take(6), key = { it.id }) { record ->
                LicenseRecordCard(record, onClick = { onRecordClick(record) })
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(toPersianDigits(value), style = MaterialTheme.typography.headlineMedium)
            Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun IssueScreen(
    state: LicenseUiState,
    viewModel: AppViewModel,
    onCopy: (String) -> Unit,
    onShare: (String, String) -> Unit,
    onSave: (String, String) -> Unit
) {
    val normalizedHwid = state.hwid.lowercase().replace("-", "").replace(" ", "")
    val hwidValid = normalizedHwid.matches(Regex("^[0-9a-f]{64}$"))
    val days = state.days.toLongOrNull()
    val expiryPreview = if (state.licenseType == LicenseType.Subscription && days != null && days > 0) {
        Instant.now().plus(days, ChronoUnit.DAYS).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("yyyy/MM/dd - HH:mm"))
    } else null

    LazyColumn(
        modifier = Modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        state.lastIssued?.let { issued ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(Modifier.width(8.dp))
                            Text("لایسنس صادر شد", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = viewModel::clearLastIssued) { Icon(Icons.Rounded.Close, "بستن") }
                        }
                        Text(
                            "مشتری: ${issued.record.customer}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            issued.token.take(48) + "…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = { onCopy(issued.token) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Rounded.ContentCopy, null)
                                Spacer(Modifier.width(6.dp))
                                Text("کپی")
                            }
                            FilledTonalButton(onClick = { onSave(issued.token, issued.record.customer) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Rounded.SaveAlt, null)
                                Spacer(Modifier.width(6.dp))
                                Text("ذخیره")
                            }
                            FilledTonalButton(onClick = { onShare(issued.token, issued.record.customer) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Rounded.Share, null)
                                Spacer(Modifier.width(6.dp))
                                Text("ارسال")
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle("اطلاعات مشتری", "مقادیر دقیقاً در لایسنس امضاشده ثبت می‌شوند.") }
        item {
            OutlinedTextField(
                value = state.customer,
                onValueChange = viewModel::updateCustomer,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نام مشتری") },
                leadingIcon = { Icon(Icons.Rounded.Person, null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
            )
        }
        item {
            OutlinedTextField(
                value = state.hwid,
                onValueChange = viewModel::updateHwid,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("HWID دستگاه") },
                leadingIcon = { Icon(Icons.Rounded.VpnKey, null) },
                minLines = 2,
                maxLines = 3,
                isError = state.hwid.isNotBlank() && !hwidValid,
                supportingText = {
                    Text(
                        if (hwidValid) "HWID معتبر است" else "${toPersianDigits(normalizedHwid.length)}/۶۴ کاراکتر هگزادسیمال"
                    )
                }
            )
        }
        item { SectionTitle("نوع و مدت", "لایسنس دائمی تاریخ انقضا ندارد.") }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LicenseType.entries.forEach { type ->
                    FilterChip(
                        selected = state.licenseType == type,
                        onClick = { viewModel.selectLicenseType(type) },
                        label = { Text(type.title) },
                        leadingIcon = {
                            Icon(
                                if (type == LicenseType.Perpetual) Icons.Rounded.AllInclusive else Icons.Rounded.CalendarMonth,
                                null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )
                }
            }
        }
        if (state.licenseType == LicenseType.Subscription) {
            item {
                OutlinedTextField(
                    value = state.days,
                    onValueChange = viewModel::updateDays,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("مدت اعتبار به روز") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                    supportingText = { expiryPreview?.let { Text("پایان تقریبی: ${toPersianDigits(it)}") } }
                )
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(7, 30, 90, 365).forEach { quick ->
                        AssistChip(onClick = { viewModel.setQuickDays(quick) }, label = { Text("${toPersianDigits(quick)} روز") })
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = state.versionPrefix,
                onValueChange = viewModel::updateVersionPrefix,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("نسخه سازگار CalcPOS") },
                supportingText = { Text("مقدار پیشنهادی برای نسخه فعلی: 1.6") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next)
            )
        }
        item {
            OutlinedTextField(
                value = state.notes,
                onValueChange = viewModel::updateNotes,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("یادداشت داخلی") },
                minLines = 2,
                maxLines = 4,
                supportingText = { Text("یادداشت در فایل لایسنس قرار نمی‌گیرد.") }
            )
        }
        item {
            Button(
                onClick = viewModel::issueLicense,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(17.dp)
            ) {
                Icon(Icons.Rounded.VpnKey, null)
                Spacer(Modifier.width(8.dp))
                Text("صدور و ثبت لایسنس")
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun HistoryScreen(state: LicenseUiState, viewModel: AppViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = state.search,
                onValueChange = viewModel::updateSearch,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("جست‌وجوی مشتری، HWID یا شناسه") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    IconButton(onClick = viewModel::refresh) { Icon(Icons.Rounded.Search, "جست‌وجو") }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { viewModel.refresh() })
            )
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LicenseStatusFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = state.filter == filter,
                        onClick = { viewModel.selectFilter(filter) },
                        label = { Text(filter.title) }
                    )
                }
            }
        }
        item {
            Text(
                "${toPersianDigits(state.records.size)} رکورد",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (state.records.isEmpty()) {
            item { EmptyState("رکوردی با این فیلتر پیدا نشد.") }
        } else {
            items(state.records, key = { it.id }) { record ->
                LicenseRecordCard(record, onClick = { viewModel.selectRecord(record) })
            }
        }
    }
}

@Composable
private fun SettingsScreen(state: LicenseUiState, viewModel: AppViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { SectionTitle("اتصال به سرور", "بعد از تغییر آدرس، دوباره وارد حساب شوید.") }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    OutlinedTextField(
                        value = state.serverUrl,
                        onValueChange = viewModel::updateServerUrl,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("آدرس Signing Server") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                    )
                    OutlinedButton(onClick = viewModel::saveServerSettings, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.SaveAlt, null)
                        Spacer(Modifier.width(8.dp))
                        Text("ذخیره تنظیمات")
                    }
                }
            }
        }
        item { SectionTitle("ظاهر برنامه", "انتخاب تم روی همین گوشی ذخیره می‌شود.") }
        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (state.darkTheme) Icons.Rounded.DarkMode else Icons.Rounded.LightMode, null)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("تم تیره", style = MaterialTheme.typography.titleMedium)
                        Text("مناسب استفاده شبانه", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = state.darkTheme, onCheckedChange = viewModel::setDarkTheme)
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Security, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("مدل امنیتی", style = MaterialTheme.typography.titleLarge)
                    }
                    Text("• کلید خصوصی RSA داخل APK قرار ندارد.")
                    Text("• توکن ورود فقط در حافظه برنامه نگهداری می‌شود.")
                    Text("• نسخه Release اتصال HTTP را رد می‌کند.")
                    Text("• فایل‌های .lic از طریق FileProvider امن اشتراک‌گذاری می‌شوند.")
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { viewModel.logout("از حساب مدیر خارج شدید.") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Rounded.Logout, null)
                Spacer(Modifier.width(8.dp))
                Text("خروج از حساب")
            }
        }
        item {
            Text(
                "CalcPOS License Manager Android ${BuildConfig.VERSION_NAME}",
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.outline,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun LicenseRecordCard(record: LicenseRecord, onClick: () -> Unit) {
    val statusColor = when {
        record.isRevoked -> MaterialTheme.colorScheme.error
        record.isExpired -> MaterialTheme.colorScheme.tertiary
        record.isPerpetual -> MaterialTheme.colorScheme.secondary
        else -> Color(0xFF16803A)
    }
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = statusColor.copy(alpha = 0.14f)) {
                Icon(
                    if (record.isPerpetual) Icons.Rounded.AllInclusive else Icons.Rounded.VpnKey,
                    null,
                    modifier = Modifier.padding(10.dp),
                    tint = statusColor
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(record.customer, style = MaterialTheme.typography.titleMedium)
                Text(
                    "HWID: ${record.hwid.take(10)}…${record.hwid.takeLast(6)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "صدور: ${formatDate(record.issuedAt)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
            Surface(shape = RoundedCornerShape(10.dp), color = statusColor.copy(alpha = 0.13f)) {
                Text(
                    record.statusTitle,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                    color = statusColor,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun LicenseDetailsDialog(
    record: LicenseRecord,
    onDismiss: () -> Unit,
    onCopyToken: () -> Unit,
    onCopyHwid: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
    onRevoke: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("جزئیات لایسنس") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.67f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                DetailLine("مشتری", record.customer)
                DetailLine("وضعیت", record.statusTitle)
                DetailLine("نوع", if (record.isPerpetual) "دائمی" else "${toPersianDigits(record.durationDays ?: 0)} روزه")
                DetailLine("شناسه", record.licenseId)
                DetailLine("HWID", record.hwid)
                DetailLine("نسخه", record.versionPrefix)
                DetailLine("تاریخ صدور", formatDate(record.issuedAt))
                DetailLine("تاریخ پایان", record.expiresAt?.let(::formatDate) ?: "بدون انقضا")
                if (record.notes.isNotBlank()) DetailLine("یادداشت", record.notes)
                HorizontalDivider()
                Text("کد لایسنس", style = MaterialTheme.typography.titleMedium)
                Text(record.token.take(160) + if (record.token.length > 160) "…" else "")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = onCopyToken, label = { Text("کپی کد") }, leadingIcon = { Icon(Icons.Rounded.ContentCopy, null) })
                    AssistChip(onClick = onCopyHwid, label = { Text("کپی HWID") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = onSave, label = { Text("ذخیره فایل") }, leadingIcon = { Icon(Icons.Rounded.SaveAlt, null) })
                    AssistChip(onClick = onShare, label = { Text("اشتراک") }, leadingIcon = { Icon(Icons.Rounded.Share, null) })
                }
                if (!record.isRevoked) {
                    OutlinedButton(
                        onClick = onRevoke,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Rounded.DeleteForever, null)
                        Spacer(Modifier.width(6.dp))
                        Text("ابطال داخلی رکورد")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(text: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Rounded.History, null, modifier = Modifier.size(38.dp), tint = MaterialTheme.colorScheme.outline)
            Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun screenTitle(screen: AppScreen): String = when (screen) {
    AppScreen.Dashboard -> "داشبورد"
    AppScreen.Issue -> "صدور لایسنس"
    AppScreen.History -> "سوابق لایسنس"
    AppScreen.Settings -> "تنظیمات"
}

private fun formatDate(value: String): String = runCatching {
    val formatted = Instant.parse(value).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("yyyy/MM/dd - HH:mm"))
    toPersianDigits(formatted)
}.getOrElse { value }

private fun toPersianDigits(value: Any): String {
    val map = mapOf('0' to '۰', '1' to '۱', '2' to '۲', '3' to '۳', '4' to '۴', '5' to '۵', '6' to '۶', '7' to '۷', '8' to '۸', '9' to '۹')
    return value.toString().map { map[it] ?: it }.joinToString("")
}
