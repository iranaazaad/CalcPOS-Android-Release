@echo off
setlocal EnableExtensions
set "GRADLE_VERSION=9.5.0"
set "CACHE_DIR=%USERPROFILE%\.gradle\calcpos-wrapper\gradle-%GRADLE_VERSION%"
set "GRADLE_BAT=%CACHE_DIR%\bin\gradle.bat"
if not exist "%GRADLE_BAT%" (
  echo Downloading Gradle %GRADLE_VERSION%...
  set "ZIP_FILE=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'; New-Item -ItemType Directory -Force '%USERPROFILE%\.gradle\calcpos-wrapper' ^| Out-Null; Expand-Archive -Force '%ZIP_FILE%' '%USERPROFILE%\.gradle\calcpos-wrapper'; Remove-Item -Force '%ZIP_FILE%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BAT%" %*
endlocal
